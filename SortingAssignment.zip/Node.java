
/**
 * Standard Cons-cells
 *
 * @author Stefan Kahrs, Nicholas Salter
 * @version 2
 * 
 */

/**
 * type parameter T
 * Below is an explanation for the fancy stuff
 * attached to that type parameter.
 * For the assessment you do not need to know this,
 * but if you are curious: read on!
 * 
 * Because we want to be able to compare the elements
 * of the list with one another, we require that
 * class T implements the Comparable interface.
 * That interface has itself a type parameter, which
 * gives you what these values can be compared to.
 * The reason this is (in the most general case) not just T
 * itself is the following scenario:
 * class X implements the interface,
 * so we can compare Xs with Xs, then we define a subclass Y of X,
 * so it inherits the compareTo method from X,
 * but Ys are now compared with Xs.
 */

import java.util.Queue;
import java.util.ArrayDeque;
import java.util.Random;
public class Node<T extends Comparable<? super T>>
{

    protected T head;
    protected Node<T> tail;

    public Node(T h, Node<T> t) {
        head = h;
        tail = t;
    }

    public String toString() {
        if (tail == null) return "[" + head + "]";
        return "[" + head + tail.tailString();
    }

    private String tailString() {
        String initialPart= "," + head;
        if (tail==null) return initialPart + "]";
        return initialPart + tail.tailString();
    }

    public int length() {
        int result=1;
        for (Node<T> n=tail; n!=null; n=n.tail) { result++; }
        return result;
    }
    
    /**
     * Seperates the linked list into a queue of segments 
     * that were already in order.
     * @return Queue<Node<T>> A queue of all sorted segments of the linked list.
     */
    public Queue<Node<T>> queueSortedSegments() {
        Queue<Node<T>> q = new ArrayDeque();
        Node<T> nodes = this;
        boolean queuing = true;
        while (queuing)
        {
            for (Node<T> n=nodes; n!=null; n=n.tail) 
            {
                if (n.tail == null)
                {
                    queuing = false;
                    q.add(nodes);
                }
                else if(n.head.compareTo(n.tail.head) > 0)
                {
                    Node<T> leftOverList = n.tail;
                    n.tail = null;
                    q.add(nodes);
                    nodes = leftOverList;
                    break;
                }
            }
        }
        return q; // Returns the queue.
    }

    /**
     * Returns whether the list is sorted or not as a boolean.
     * @return boolean Returns whether the list is sorted.
     */
    public boolean isSorted() {
        boolean sorted = true;
        T lastT = null;
        if (this == null)
        {
            return false;
        }
        for (Node<T> n=tail; n!=null; n=n.tail) 
        {
            if(lastT != null)
            {
                if (n.head.compareTo(lastT) < 0)
                {
                    sorted = false;
                }
            }
            lastT = n.head;
        }
        //this method should check whether 'this' list is already sorted
        return sorted; 
    }

    /**
     * Merges the current first node of the current list with 
     * another first node of another list and returns the
     * first node of a combined linked list.
     * @param Node<T> another The other starting node being entered.
     * @return Node<T> The starting node of the combined linked list.
     */
    public Node<T> merge (Node<T> another){
        //this method should merge two sorted linked lists
        //and return their merged resulting list
        assert isSorted();
        assert another==null || another.isSorted();
        Node<T> returnNode = null;
        Node<T> temp = this;
        if(head.compareTo(another.head) < 0)
        {
            returnNode = temp;
            temp = temp.tail;
        }
        else
        {
            returnNode = another;
            another = another.tail;
        }
        Node<T> savedNode = returnNode;
        boolean testing = true;
        while (temp != null && another != null) 
        {
            if(temp.head.compareTo(another.head) < 0)
            {
                returnNode.tail = temp;
                temp = temp.tail;
                returnNode = returnNode.tail;
            }
            else
            {
                returnNode.tail = another;
                another = another.tail;
                returnNode = returnNode.tail;
            }
        }
        if(temp != null)
        {

            returnNode.tail = temp;

        }
        else if (another != null)
        {
            returnNode.tail = another;
        }
        return savedNode;
    }

    /**
     * Returns the starting node of a sorted linked list.
     * @return The first node to the sorted linked list.
     */
    public Node<T> mergeSort() {
        Queue<Node<T>> mQ = queueSortedSegments();  //split the list up into sorted segments and place these into a queue
        if(mQ.peek() == null)
        {
            return null;
        }
        Node<T> toBeMerged1 = mQ.remove();
        Node<T> toBeMerged2 = null;
        //poll pairs of lists from the queue, merge them, and put their merge
        if (mQ.peek() != null)
        {
            toBeMerged2 = mQ.remove();
            mQ.add(toBeMerged1.merge(toBeMerged2)); //back into the queue
        }
        else
        {
            mQ.add(toBeMerged1);    //back into the queue
        }
        while(toBeMerged2 != null)
        {
            toBeMerged1 = mQ.remove();
            if (mQ.peek() != null)
            {
                toBeMerged2 = mQ.remove();
                mQ.add(toBeMerged1.merge(toBeMerged2)); //back into the queue
            }
            else
            {
                toBeMerged2 = null;
                mQ.add(toBeMerged1);    //back into the queue
            }
        }
        //if there is only one list left in the queue that should be returned
        return mQ.remove(); // Return only item in list.
    }

    /**
     * Returns the first integer node of linked list of a size 
     * inputted by their user.
     * @param int n Linked list size.
     * @return Node<Integer> The beginning node of the linked list made.
     */
    static public Node<Integer> randomList(int n) {
        //for testing purposes we want some random lists to be sorted
        //the list is n elements long
        //the elements of the random list are numbers between 0 and n-1
        Random r=new Random();
        Node<Integer> result=null;
        int k=n;
        while(k>0) { 
            result=new Node<Integer>(r.nextInt(n),result);
            k--;
        }
        return result;
    }
    
    /**
     * Creates a random linked list, displays it, tests whether 
     * it is sorted or not and then sorts it, displays it and 
     * then tests to see whether the sorting was successful.
     * @param int n Size of the list being made and tested. It must be greater than 0.
     */
    static public void test(int n) {
        if(n < 1)
        {
            System.out.println("Please Enter List Value of Greater than 1.");
            return;
        }
        Node node = randomList(n);              //1. create a random linked list of length n
        System.out.println(node);               //2. output it
        System.out.println(node.isSorted());    //3. report whether the 'isSorted' method thinks the list is sorted or not
        node = node.mergeSort();                //4. sort the list using mergeSort
        System.out.println(node);               //5. output the sorted list
        System.out.println(node.isSorted());    //6. report whether the 'isSorted' method thinks that list is sorted or not
    }

}